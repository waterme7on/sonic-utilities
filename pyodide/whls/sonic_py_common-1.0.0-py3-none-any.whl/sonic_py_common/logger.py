# import os
# import sys
# import syslog

# """
# Logging functionality for SONiC Python applications
# """


# class Logger(object):
#     """
#     Logger class for SONiC Python applications
#     """
#     LOG_FACILITY_DAEMON = syslog.LOG_DAEMON
#     LOG_FACILITY_USER = syslog.LOG_USER

#     LOG_OPTION_NDELAY = syslog.LOG_NDELAY
#     LOG_OPTION_PID = syslog.LOG_PID

#     LOG_PRIORITY_ERROR = syslog.LOG_ERR
#     LOG_PRIORITY_WARNING = syslog.LOG_WARNING
#     LOG_PRIORITY_NOTICE = syslog.LOG_NOTICE
#     LOG_PRIORITY_INFO = syslog.LOG_INFO
#     LOG_PRIORITY_DEBUG = syslog.LOG_DEBUG

#     DEFAULT_LOG_FACILITY = LOG_FACILITY_USER
#     DEFAULT_LOG_OPTION = LOG_OPTION_NDELAY

#     def __init__(self, log_identifier=None, log_facility=DEFAULT_LOG_FACILITY, log_option=DEFAULT_LOG_OPTION):
#         self._syslog = syslog

#         if log_identifier is None:
#             log_identifier = os.path.basename(sys.argv[0])

#         # Initialize syslog
#         self._syslog.openlog(ident=log_identifier, logoption=log_option, facility=log_facility)

#         # Set the default minimum log priority to LOG_PRIORITY_NOTICE
#         self.set_min_log_priority(self.LOG_PRIORITY_NOTICE)

#     def __del__(self):
#         self._syslog.closelog()

#     #
#     # Methods for setting minimum log priority
#     #

#     def set_min_log_priority(self, priority):
#         """
#         Sets the minimum log priority level to <priority>. All log messages
#         with a priority lower than <priority> will not be logged

#         Args:
#             priority: The minimum priority at which to log messages
#         """
#         self._min_log_priority = priority

#     def set_min_log_priority_error(self):
#         """
#         Convenience function to set minimum log priority to LOG_PRIORITY_ERROR
#         """
#         self.set_min_log_priority(self.LOG_PRIORITY_ERROR)

#     def set_min_log_priority_warning(self):
#         """
#         Convenience function to set minimum log priority to LOG_PRIORITY_WARNING
#         """
#         self.set_min_log_priority(self.LOG_PRIORITY_WARNING)

#     def set_min_log_priority_notice(self):
#         """
#         Convenience function to set minimum log priority to LOG_PRIORITY_NOTICE
#         """
#         self.set_min_log_priority(self.LOG_PRIORITY_NOTICE)

#     def set_min_log_priority_info(self):
#         """
#         Convenience function to set minimum log priority to LOG_PRIORITY_INFO
#         """
#         self.set_min_log_priority(self.LOG_PRIORITY_INFO)

#     def set_min_log_priority_debug(self):
#         """
#         Convenience function to set minimum log priority to LOG_PRIORITY_DEBUG
#         """
#         self.set_min_log_priority(self.LOG_PRIORITY_DEBUG)

#     #
#     # Methods for logging messages
#     #

#     def log(self, priority, msg, also_print_to_console=False):
#         if self._min_log_priority >= priority:
#             # Send message to syslog
#             self._syslog.syslog(priority, msg)

#             # Send message to console
#             if also_print_to_console:
#                 print(msg)

#     def log_error(self, msg, also_print_to_console=False):
#         self.log(self.LOG_PRIORITY_ERROR, msg, also_print_to_console)

#     def log_warning(self, msg, also_print_to_console=False):
#         self.log(self.LOG_PRIORITY_WARNING, msg, also_print_to_console)

#     def log_notice(self, msg, also_print_to_console=False):
#         self.log(self.LOG_PRIORITY_NOTICE, msg, also_print_to_console)

#     def log_info(self, msg, also_print_to_console=False):
#         self.log(self.LOG_PRIORITY_INFO, msg, also_print_to_console)

#     def log_debug(self, msg, also_print_to_console=False):
#         self.log(self.LOG_PRIORITY_DEBUG, msg, also_print_to_console)
