from setuptools import setup
setup(name='sonic_py_common', version='1.0.0', py_modules=[
    'daemon_base',
    'device_info',
    'general',
    'interface',
    'logger',
    'multi_asic',
    'port_util',
    'sonic_db_dump_load',
    'task_base',
    'util',
    ])
