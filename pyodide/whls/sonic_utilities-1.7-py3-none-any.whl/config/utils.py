from sonic_py_common import logger

SYSLOG_IDENTIFIER = "config"

# Global logger instance
log = logger.Logger(SYSLOG_IDENTIFIER)
