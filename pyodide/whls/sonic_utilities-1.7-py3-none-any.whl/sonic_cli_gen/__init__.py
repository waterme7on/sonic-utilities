#!/usr/bin/env python

from sonic_cli_gen.generator import CliGenerator

__all__ = ['CliGenerator']

