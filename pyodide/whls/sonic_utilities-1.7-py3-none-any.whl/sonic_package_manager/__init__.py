#!/usr/bin/env python

from sonic_package_manager.manager import PackageManager

__all__ = ['PackageManager']
