#!/usr/bin/env python

ETC_SONIC_PATH = '/etc/sonic'
SONIC_CLI_COMMANDS = ('show', 'config', 'clear')
